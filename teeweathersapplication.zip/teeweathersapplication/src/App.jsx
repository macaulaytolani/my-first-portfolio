import React, { useEffect, useRef } from 'react';
import './App.css';

// Helper: query the DOM directly (no React state)
const $ = (selector) => document.querySelector(selector);

const GEOCODING_API = 'https://geocoding-api.open-meteo.com/v1/search';
const WEATHER_API = 'https://api.open-meteo.com/v1/forecast';

// Resolve a city name to lat/lon via Open-Meteo geocoding
const geocodeCity = async (city) => {
  const res = await fetch(`${GEOCODING_API}?name=${encodeURIComponent(city)}&count=1`);
  if (!res.ok) throw new Error('Geocoding request failed');
  const data = await res.json();
  if (!data.results || data.results.length === 0) {
    throw new Error(`City "${city}" not found`);
  }
  const { name, latitude, longitude, timezone } = data.results[0];
  return { name, latitude, longitude, timezone };
};

// Fetch current weather for given coordinates
const fetchWeather = async (lat, lon, timezone) => {
  const url = `${WEATHER_API}?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,wind_speed_10m&timezone=${timezone || 'auto'}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Weather request failed');
  const data = await res.json();
  const current = data.current;
  return {
    temp: Math.round(current.temperature_2m),
    humidity: current.relative_humidity_2m,
    wind: Math.round(current.wind_speed_10m),
  };
};

export default function App() {
  const inputRef = useRef(null);

  // On mount, load a default city using query selectors
  useEffect(() => {
    loadWeather('London');
  }, []);

  const loadWeather = async (city) => {
    const statusEl = $('.status');
    if (statusEl) statusEl.textContent = 'Loading...';

    try {
      const geo = await geocodeCity(city);
      const weather = await fetchWeather(geo.latitude, geo.longitude, geo.timezone);

      
      $('.city-name').textContent = geo.name;
      $('.temp').textContent = `${weather.temp}°C`;
      $('.condition').textContent = `Humidity: ${weather.humidity}%`;
      $('.humidity').textContent = `Humidity: ${weather.humidity}%`;
      $('.wind').textContent = `Wind: ${weather.wind} km/h`;
      if (statusEl) statusEl.textContent = '';
    } catch (err) {
      if (statusEl) statusEl.textContent = err.message || 'Error loading weather';
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const city = inputRef.current.value.trim();
    if (city) loadWeather(city);
  };

  return (
    <div className="app">
      <form className="search-form" onSubmit={handleSubmit}>
        <input
          ref={inputRef}
          type="text"
          className="city-input"
          placeholder="Enter city name..."
        />
        <button type="submit" className="search-btn">
          Get Weather
        </button>
      </form>

      <div className="status"></div>

      <div className="weather-card">
        <h1 className="city-name">—</h1>
        <div className="temp">—°C</div>
        <div className="condition">—</div>
        <div className="details">
          <span className="humidity">Humidity: —%</span>
          <span className="wind">Wind: — km/h</span>
        </div>
      </div>
    </div>
  );
}